function NumericalMethodsApp()
    % Create UI Figure Window
    fig = uifigure('Name', 'Numerical Methods Solver', 'Position', [100, 100, 560, 420]);
    
    % Title
    uilabel(fig, 'Position', [20, 370, 500, 30], ...
        'Text', 'Numerical Methods App (Root Finding)', ...
        'FontSize', 16, 'FontWeight', 'bold');
    
    % Method Selection
    uilabel(fig, 'Position', [20, 320, 100, 22], 'Text', 'Select Method:');
    methodDropdown = uidropdown(fig, 'Position', [130, 320, 180, 22], ...
        'Items', {'Bisection', 'Newton-Raphson', 'Secant'});
    
    % Function Input
    uilabel(fig, 'Position', [20, 270, 100, 22], 'Text', 'Function f(x):');
    funcEdit = uieditfield(fig, 'text', 'Position', [130, 270, 220, 22], 'Value', 'x^3 - x - 2');
    
    % Parameter A / Initial Guess 1
    uilabel(fig, 'Position', [20, 220, 120, 22], 'Text', 'Param A (a / x0):');
    paramAEdit = uieditfield(fig, 'numeric', 'Position', [130, 220, 100, 22], 'Value', 1);
    
    % Parameter B / Initial Guess 2
    uilabel(fig, 'Position', [270, 220, 140, 22], 'Text', 'Param B (b / x1):');
    paramBEdit = uieditfield(fig, 'numeric', 'Position', [410, 220, 100, 22], 'Value', 2);
    
    % Tolerance
    uilabel(fig, 'Position', [20, 170, 100, 22], 'Text', 'Tolerance:');
    tolEdit = uieditfield(fig, 'numeric', 'Position', [130, 170, 100, 22], 'Value', 1e-5);
    
    % Result Display Area
    resultArea = uitextarea(fig, 'Position', [20, 20, 520, 50], 'Editable', 'off');

    % Solve Button
    uibutton(fig, 'Position', [130, 110, 150, 35], ...
        'Text', 'Calculate Root', ...
        'ButtonPushedFcn', @(~,~) solveNumericalMethod(methodDropdown, funcEdit, paramAEdit, paramBEdit, tolEdit, resultArea));
end

function solveNumericalMethod(methodDropdown, funcEdit, paramAEdit, paramBEdit, tolEdit, resultArea)
    try
        method = methodDropdown.Value;
        funcStr = funcEdit.Value;
        p1 = paramAEdit.Value;
        p2 = paramBEdit.Value;
        tol = tolEdit.Value;

        % Create anonymous function safely
        f = str2func(['@(x) ' funcStr]);
        
        if strcmp(method, 'Bisection')
            a = p1; b = p2;
            if f(a) * f(b) > 0
                resultArea.Value = {'Error: f(a) and f(b) must have opposite signs.'};
                return;
            end
            iter = 0; maxIter = 100;
            while (b - a)/2 > tol && iter < maxIter
                c = (a + b)/2;
                if f(c) == 0, break;
                elseif f(a) * f(c) < 0, b = c;
                else, a = c;
                end
                iter = iter + 1;
            end
            root = (a + b)/2;
            resultArea.Value = {sprintf('Root found: %.6f after %d iterations.', root, iter)};
            
        elseif strcmp(method, 'Newton-Raphson')
            x = p1;
            iter = 0; maxIter = 100;
            h = 1e-5; % Step size for numerical derivative
            
            while iter < maxIter
                fx = f(x);
                dfx = (f(x + h) - f(x - h)) / (2 * h);
                
                if abs(dfx) < 1e-12
                    resultArea.Value = {'Derivative is zero. Method failed.'};
                    return;
                end
                
                x_next = x - fx/dfx;
                
                if abs(x_next - x) < tol
                    root = x_next;
                    resultArea.Value = {sprintf('Root found: %.6f after %d iterations.', root, iter+1)};
                    return;
                end
                
                x = x_next;
                iter = iter + 1;
            end
            resultArea.Value = {'Max iterations reached without convergence.'};
            
        elseif strcmp(method, 'Secant')
            x0 = p1; 
            x1 = p2;
            iter = 0; maxIter = 100;
            
            while iter < maxIter
                fx0 = f(x0);
                fx1 = f(x1);
                
                if abs(fx1 - fx0) < 1e-12
                    resultArea.Value = {'Division by zero in Secant method.'};
                    return;
                end
                
                % Secant formula
                x2 = x1 - fx1 * (x1 - x0) / (fx1 - fx0);
                
                if abs(x2 - x1) < tol
                    root = x2;
                    resultArea.Value = {sprintf('Root found: %.6f after %d iterations.', root, iter+1)};
                    return;
                end
                
                x0 = x1;
                x1 = x2;
                iter = iter + 1;
            end
            resultArea.Value = {'Max iterations reached without convergence.'};
        end
        
    catch ME
        disp(ME);
        resultArea.Value = {['Error: ' ME.message]};
    end
end